sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"be/flexsohacktest/model/models"
], function(UIComponent, Device, models) {
	"use strict";

	return UIComponent.extend("be.flexsohacktest.Component", {
		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);
            var mConfig = this.getMetadata().getConfig();
            var sServiceUrl = "/public/HackAJob/services/search.xsodata/public/HackAJob/services/search.xsodata";
            var oModel = new sap.ui.model.odata.ODataModel(sServiceUrl, {
            	json: true,
            	loadMetadataAsync: true
            });
			// set the device model
			this.setModel(oModel);
		}
	});
});