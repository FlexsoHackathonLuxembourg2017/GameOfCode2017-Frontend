sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function() {
//		    var queryString ="$format=json";	
//			var oModel = new JSONModel(Device);
//			oModel.setDefaultBindingMode("OneWay");
//			var URL = "https://flexsolus0011141903trial.hanatrial.ondemand.com/public/HackAJob/services/search.xsodata/skills";
//			oModel.loadData( URL, queryString);
//			return oModel;
		}

	};
});