sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("be.flexsohacktest.controller.GoogleMap", {
		findLocation: function() {
			//			if(navigator.geolocation){
			//				navigator.geolocation.getCurrentPosition(function(position){
			//			var pos = new google.maps.LatLng(position.coords.latitude,position.coords.longitude);
			var pos = new google.maps.LatLng("49.600958", "6.112918");
			map.setCenter(pos);
			var infowindow = new google.maps.InfoWindow({
				map: map,
				position: pos,
				content: 'This is Hackathon position\n'
			});
			//				});
		},

		initMap: function() {

			var mapOptions = {
				zoom: 9
			};
			var test2 = $("#__xmlview0--map\_canvas")[0];
			map = new google.maps.Map(test2, mapOptions);

			var marker = new google.maps.Marker({
				map: map,
				// Define the place with a location, and a query string.
				place: {
					location: {
						lat: 49.963740,
						lng: 5.919859
					},
					query: 'ADEM, Luxembourg'

				},
				// Attributions help users find your site again.
				attribution: {
					source: 'ADEM',
					webUrl: "http://www.adem.public.lu/fr/index.html"
				}
			});

			// Construct a new InfoWindow.
			var infoWindow = new google.maps.InfoWindow({
				content: 'ADEM'
			});

			// Opens the InfoWindow when marker is clicked.
			marker.addListener('click', function() {
				infoWindow.open(map, marker);
			});

			var marker2 = new google.maps.Marker({
				map: map,
				// Define the place with a location, and a query string.
				place: {
					location: {
						lat: 49.581777,
						lng: 6.112085
					},
					query: 'Alter Domus, Luxembourg'

				},
			});

			// Construct a new InfoWindow.
			var infoWindow2 = new google.maps.InfoWindow({
				content: 'Alter Domus'
			});
			// Opens the InfoWindow when marker is clicked.
			marker2.addListener('click', function() {
				infoWindow2.open(map, marker2);
			});

		},

		onAfterRendering: function() {

			var test = $("#__xmlview1--map\_canvas")[0];
			test.setAttribute("style", "height:100vh");
			google.maps.event.addDomListener(window, "load", this.initMap());
			this.findLocation();

		},
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf be.flexsohacktest.view.GoogleMap
		 */
		//	onInit: function() {
		//
		//	},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf be.flexsohacktest.view.GoogleMap
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf be.flexsohacktest.view.GoogleMap
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf be.flexsohacktest.view.GoogleMap
		 */
		//	onExit: function() {
		//
		//	}

	});

});