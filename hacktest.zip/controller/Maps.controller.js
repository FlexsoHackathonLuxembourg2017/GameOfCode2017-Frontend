sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	'sap/ui/model/Filter',
	'sap/m/Dialog',
	'sap/m/MessageToast',
	'sap/m/Button',
	'sap/m/RatingIndicator',
	'sap/m/ComboBox',

], function(Controller, JSONModel, Filter, Dialog, MessageToast, Button, RatingIndicator, ComboBox) {
	//	"use strict";
	return Controller.extend("be.flexsohacktest.controller.Maps", {
		onAddSkills: function() {
			var oItemTemplate = new sap.ui.core.Item({
				key: "{SKILL}",
				text: "{SKILL}"
			});
			var dialog = new Dialog({
				title: 'Add a skill',
				type: 'Message',
				content: [
					new ComboBox("ComboBox", {
						required: true,
						editable: true,
						tooltip: "Skill",
						items: {
							path: "{/SkillDetails}",
							template: oItemTemplate
						}
					}),
					new RatingIndicator({
						maxValue: 10,
						value: 5,
						tooltip: "Rating"
					})
				],
				beginButton: new Button({
					text: 'Add',
					press: function() {
						MessageToast.show('Submit pressed!');
						dialog.close();
					}
				}),
				endButton: new Button({
					text: 'Cancel',
					press: function() {
						dialog.close();
					}
				}),
				afterClose: function() {
					dialog.destroy();
				}
			});

			dialog.open();
		},
		onPressMap: function() {
			this.hideMe();
			this.hideCompany();
			this.getView().byId("__xmlview0--maptab").setVisible(true);
			var test = $("#__xmlview0--map\_canvas")[0];
			test.setAttribute("style", "height:100vh");
			google.maps.event.addDomListener(window, "load", this.initMap());
			this.findLocation();
		},
		onInit: function() {},
		hideMe: function(event) {
			this.getView().byId("__xmlview0--tabPref").setVisible(false);
			this.getView().byId("__xmlview0--tabSkil").setVisible(false);
			this.getView().byId("__xmlview0--tabInfo").setVisible(false);
		},
		hideCompany: function(event) {
			this.getView().byId("__xmlview0--tabAct").setVisible(false);
			this.getView().byId("__xmlview0--tabPost").setVisible(false);
			this.getView().byId("__xmlview0--tabName").setVisible(false);
		},
		showMe: function(event) {
			this.getView().byId("__xmlview0--tabPref").setVisible(true);
			this.getView().byId("__xmlview0--tabSkil").setVisible(true);
			this.getView().byId("__xmlview0--tabInfo").setVisible(true);
		},
		showCompany: function(event) {
			this.getView().byId("__xmlview0--tabAct").setVisible(true);
			this.getView().byId("__xmlview0--tabPost").setVisible(true);
			this.getView().byId("__xmlview0--tabName").setVisible(true);
		},

		onPressMe: function(event) {
			this.getView().byId("__xmlview0--maptab").setVisible(false);
			var sKey = event.getParameter("id");
			if (sKey === "__xmlview0--Me") {
				this.hideCompany();
				this.showMe();
			} else if (sKey === "__xmlview0--Comp") {
				this.showCompany();
				this.hideMe();
			}
		},
		onPressMyCV: function(event) {
			this.hideCompany();
			this.showMe();
			this.getView().byId("__xmlview0--TabMe").setSelectedKey("skill");
		},
		onPressMyInfo: function(event) {
			this.hideCompany();
			this.showMe();
			this.getView().byId("__xmlview0--TabMe").setSelectedKey("info");
		},
		onPressMyPref: function(event) {
			this.hideCompany();
			this.showMe();
			this.getView().byId("__xmlview0--TabMe").setSelectedKey("pref");
		},
		onPressCompany: function(event) {
			this.getView().byId("__xmlview0--maptab").setVisible(false);
			this.showCompany();
			this.hideMe();
		},
		onPressCompName: function(event) {
			this.showCompany();
			this.hideMe();
			this.getView().byId("__xmlview0--TabMe").setSelectedKey("name");
		},
		onPressCompPostcode: function(event) {
			this.showCompany();
			this.hideMe();
			this.getView().byId("__xmlview0--TabMe").setSelectedKey("post");
		},
		onPressCompArea: function(event) {
			this.showCompany();
			this.hideMe();
			this.getView().byId("__xmlview0--TabMe").setSelectedKey("act");
		},
		handleSuggestAdrres: function(oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			if (sTerm) {
				aFilters.push(new Filter("STREET", sap.ui.model.FilterOperator.StartsWith, sTerm));
			}
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
		},

		findLocation: function() {
			//			if(navigator.geolocation){
			//				navigator.geolocation.getCurrentPosition(function(position){
			//			var pos = new google.maps.LatLng(position.coords.latitude,position.coords.longitude);
			var pos = new google.maps.LatLng("49.600958", "6.112918");
			map.setCenter(pos);
			var infowindow = new google.maps.InfoWindow({
				map: map,
				position: pos,
				content: 'This is your position\n'
			});
			//				});
		},
		onClose: function(evt) {
			this.addSkillFragment.close();
		},
		onDisplayMap: function() {
			// //Create fragment if not done yet
			// if (!this.addSkillFragment) {
			// 	//do this only once
			// 	this.addSkillFragment = sap.ui.xmlfragment(
			// 		"createSkillDialog",
			// 		"be.flexsohacktest.view.fragments.GoogleMap",
			// 		this);
			// 	this.getView().addDependent(this.addSkillFragment);
			// }
			// Other solution
			// var initData = {skill:"",score:0};
			// var addSkillModel=new JSONModel(initData);
			// this.addSkillFragment.setModel(addSkillModel,"skill");
			this.hideMe();
			this.hideCompany();
			var test = $("#__xmlview0--map\_canvas")[0];
			test.setAttribute("style", "height:100vh");
			google.maps.event.addDomListener(window, "load", this.initMap());
			this.findLocation();
			//			this.addSkillFragment.open();
		},

		initMap: function() {

			var mapOptions = {
				zoom: 13
			};
			var test2 = $("#__xmlview0--map\_canvas")[0];
			//			var test2 = $("#createSkillDialog--map\_canvas")[0];
			map = new google.maps.Map(test2, mapOptions);
			var result = new JSONModel();
			result = [{
				COMPANY: "A+P Kieffer Omnitec SARL",
				DESCRIPTION: "Electrical installation",
				LATITUDE: "49.581789",
				LONGITUDE: "6.11208699999999"
			}, {
				COMPANY: "AlphaGruppe SARL",
				DESCRIPTION: "Construction of residential and non-residential buildings",
				LATITUDE: "50.077744",
				LONGITUDE: "6.070907"
			}, {
				COMPANY: "Baatz Constructions Exploitation SARL",
				DESCRIPTION: "Construction of roads and motorways",
				LATITUDE: "49.654581",
				LONGITUDE: "6.22109799999999"
			}, {
				COMPANY: "Baatz Constructions Exploitation SARL",
				DESCRIPTION: "Construction of roads and motorways",
				LATITUDE: "49.49151899999999",
				LONGITUDE: "5.977552",
			}, {
				COMPANY: "C. Karp-Kneip Constructions SA",
				DESCRIPTION: "Construction of roads and motorways",
				LATITUDE: "49.59417499999999",
				LONGITUDE: "6.106544"
			}, {
				COMPANY: "CBL SA",
				DESCRIPTION: "Construction of residential and non-residential buildings",
				LATITUDE: "49.522252",
				LONGITUDE: "6.01435799999999"
			}, {
				COMPANY: "CLE Cie Luxembourgeoise d'Entreprises SA",
				DESCRIPTION: "Construction of residential and non-residential buildings",
				LATITUDE: "49.616343",
				LONGITUDE: "6.09213999999999"
			}];

			for (var i = 0; i < 7; i++) {
				var latitude = result[i].LATITUDE;
				var longitude = result[i].LONGITUDE;
				var company = result[i].COMPANY;
				var marker = new google.maps.Marker({
					map: map,
					// Define the place with a location, and a query string.
					place: {
						location: {
							lat: latitude,
							lng: longitude,
						},
						query: company

					},
					// Attributions help users find your site again.
					attribution: {
						source: company,
					}
				});
				var infoWindow = new google.maps.InfoWindow({
					content: company
				});

				// Opens the InfoWindow when marker is clicked.
				marker.addListener('click', function() {
					infoWindow.open(map, marker);
				});
			}
			
			var marker = new google.maps.Marker({
				map: map,
				// Define the place with a location, and a query string.
				place: {
					location: {
						lat: 49.963740,
						lng: 5.919859
					},
					query: 'ADEM, Luxembourg'

				},
				// Attributions help users find your site again.
				attribution: {
					source: "ADEM",
					webUrl: "http://www.adem.public.lu/fr/index.html"
				}
			});

			// Construct a new InfoWindow.
			var infoWindow = new google.maps.InfoWindow({
				content: "ADEM"
			});

			// Opens the InfoWindow when marker is clicked.
			marker.addListener('click', function() {
				infoWindow.open(map, marker);
			});

			var marker2 = new google.maps.Marker({
				map: map,
				// Define the place with a location, and a query string.
				place: {
					location: {
						lat: 49.581777,
						lng: 6.112085
					},
					query: 'Alter Domus, Luxembourg'

				},
				// Attributions help users find your site again.
				attribution: {
					source: 'Alter Domus',
					webUrl: "http://www.alterdomus.com/offices-desks/europe/luxembourg-office"
				}
			});
			var contentString = '<div id="content">' +
				'<div id="bodyContent">' +
				'<p>WebSite : <a href="http://www.alterdomus.com/offices-desks/europe/luxembourg-office">' +
				+'</a></p>' +
				'</div>' +
				'</div>';
			// Construct a new InfoWindow.
			var infoWindow2 = new google.maps.InfoWindow({
				content: contentString
			});
			// Opens the InfoWindow when marker is clicked.
			marker2.addListener('click', function() {
				infoWindow2.open(map, marker2);
			});

		},

		// onAfterRendering: function() {

		// 	var test = $("#__xmlview0--map\_canvas")[0];
		// 	test.setAttribute("style", "height:100vh");
		// 	google.maps.event.addDomListener(window, "load", this.initMap());
		// 	this.findLocation();

		// },
	});
});